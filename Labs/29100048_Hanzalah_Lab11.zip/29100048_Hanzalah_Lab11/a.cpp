// g++ -std=c++17 test.cpp -o tests && ./tests ->test case command

#include <iostream>
#include <string>
using namespace std;


int main() {
    string a = "hello";
    char *b = &a[0];
    cout << b;

    return 0;
}
